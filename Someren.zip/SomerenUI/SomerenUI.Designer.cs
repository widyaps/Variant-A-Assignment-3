﻿namespace SomerenUI
{
    partial class SomerenUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SomerenUI));
            this.imgDashboard = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dashboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dashboardToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lecturersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activitiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roomsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drinksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlDashboard = new System.Windows.Forms.Panel();
            this.lbl_Dashboard = new System.Windows.Forms.Label();
            this.pnlStudents = new System.Windows.Forms.Panel();
            this.listViewStudents = new System.Windows.Forms.ListView();
            this.studentID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.studentName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.studentDOB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_Students = new System.Windows.Forms.Label();
            this.pnlRooms = new System.Windows.Forms.Panel();
            this.pnlLecturers = new System.Windows.Forms.Panel();
            this.listViewLecturers = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbl_lecturers = new System.Windows.Forms.Label();
            this.listViewRooms = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbl_Rooms = new System.Windows.Forms.Label();
            this.pnlDrinks = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.DeleteQueryButton = new System.Windows.Forms.Button();
            this.DeleteQueryNameBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DeleteQuerylbl = new System.Windows.Forms.Label();
            this.AddQueryButton = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.NewQueryIDBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.NewQuerySoldBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.NewQueryPriceBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.NewQueryStockBox = new System.Windows.Forms.TextBox();
            this.NewQueryNameBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.NewPriceBox = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.NewNameBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.NewStockBox = new System.Windows.Forms.TextBox();
            this.DrinkNameBox = new System.Windows.Forms.TextBox();
            this.listViewDrinks = new System.Windows.Forms.ListView();
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.AddQueryButt = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.NewQuerySold = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.NewQueryPrice = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.NewQueryStock = new System.Windows.Forms.TextBox();
            this.NewQueryName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.UpdatePriceButton = new System.Windows.Forms.Button();
            this.lbl_NewPrice = new System.Windows.Forms.Label();
            this.UpdateNameButton = new System.Windows.Forms.Button();
            this.lbl_NewName = new System.Windows.Forms.Label();
            this.lbl_NewStock = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_DrinkName = new System.Windows.Forms.Label();
            this.UpdateStockButton = new System.Windows.Forms.Button();
            this.listViewDrinkss = new System.Windows.Forms.ListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lbl_Drinks = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.imgDashboard)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.pnlDashboard.SuspendLayout();
            this.pnlStudents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlRooms.SuspendLayout();
            this.pnlLecturers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlDrinks.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // imgDashboard
            // 
            this.imgDashboard.Location = new System.Drawing.Point(940, 0);
            this.imgDashboard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.imgDashboard.Name = "imgDashboard";
            this.imgDashboard.Size = new System.Drawing.Size(467, 415);
            this.imgDashboard.TabIndex = 0;
            this.imgDashboard.TabStop = false;
            this.imgDashboard.Click += new System.EventHandler(this.imgDashboard_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashboardToolStripMenuItem,
            this.studentsToolStripMenuItem,
            this.lecturersToolStripMenuItem,
            this.activitiesToolStripMenuItem,
            this.roomsToolStripMenuItem,
            this.drinksToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1443, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dashboardToolStripMenuItem
            // 
            this.dashboardToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashboardToolStripMenuItem1,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.dashboardToolStripMenuItem.Name = "dashboardToolStripMenuItem";
            this.dashboardToolStripMenuItem.Size = new System.Drawing.Size(118, 29);
            this.dashboardToolStripMenuItem.Text = "Application";
            this.dashboardToolStripMenuItem.Click += new System.EventHandler(this.dashboardToolStripMenuItem_Click);
            // 
            // dashboardToolStripMenuItem1
            // 
            this.dashboardToolStripMenuItem1.Name = "dashboardToolStripMenuItem1";
            this.dashboardToolStripMenuItem1.Size = new System.Drawing.Size(202, 34);
            this.dashboardToolStripMenuItem1.Text = "Dashboard";
            this.dashboardToolStripMenuItem1.Click += new System.EventHandler(this.dashboardToolStripMenuItem1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(199, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(202, 34);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // studentsToolStripMenuItem
            // 
            this.studentsToolStripMenuItem.Name = "studentsToolStripMenuItem";
            this.studentsToolStripMenuItem.Size = new System.Drawing.Size(97, 29);
            this.studentsToolStripMenuItem.Text = "Students";
            this.studentsToolStripMenuItem.Click += new System.EventHandler(this.studentsToolStripMenuItem_Click);
            // 
            // lecturersToolStripMenuItem
            // 
            this.lecturersToolStripMenuItem.Name = "lecturersToolStripMenuItem";
            this.lecturersToolStripMenuItem.Size = new System.Drawing.Size(98, 29);
            this.lecturersToolStripMenuItem.Text = "Lecturers";
            this.lecturersToolStripMenuItem.Click += new System.EventHandler(this.lecturersToolStripMenuItem_Click);
            // 
            // activitiesToolStripMenuItem
            // 
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new System.Drawing.Size(98, 29);
            this.activitiesToolStripMenuItem.Text = "Activities";
            // 
            // roomsToolStripMenuItem
            // 
            this.roomsToolStripMenuItem.Name = "roomsToolStripMenuItem";
            this.roomsToolStripMenuItem.Size = new System.Drawing.Size(84, 29);
            this.roomsToolStripMenuItem.Text = "Rooms";
            this.roomsToolStripMenuItem.Click += new System.EventHandler(this.roomsToolStripMenuItem_Click);
            // 
            // drinksToolStripMenuItem
            // 
            this.drinksToolStripMenuItem.Name = "drinksToolStripMenuItem";
            this.drinksToolStripMenuItem.Size = new System.Drawing.Size(78, 29);
            this.drinksToolStripMenuItem.Text = "Drinks";
            this.drinksToolStripMenuItem.Click += new System.EventHandler(this.drinksToolStripMenuItem_Click_1);
            // 
            // pnlDashboard
            // 
            this.pnlDashboard.Controls.Add(this.lbl_Dashboard);
            this.pnlDashboard.Controls.Add(this.imgDashboard);
            this.pnlDashboard.Location = new System.Drawing.Point(18, 41);
            this.pnlDashboard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlDashboard.Name = "pnlDashboard";
            this.pnlDashboard.Size = new System.Drawing.Size(1407, 718);
            this.pnlDashboard.TabIndex = 2;
            // 
            // lbl_Dashboard
            // 
            this.lbl_Dashboard.AutoSize = true;
            this.lbl_Dashboard.Location = new System.Drawing.Point(19, 20);
            this.lbl_Dashboard.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Dashboard.Name = "lbl_Dashboard";
            this.lbl_Dashboard.Size = new System.Drawing.Size(275, 20);
            this.lbl_Dashboard.TabIndex = 1;
            this.lbl_Dashboard.Text = "Welcome to the Someren Application!";
            this.lbl_Dashboard.Click += new System.EventHandler(this.label1_Click);
            // 
            // pnlStudents
            // 
            this.pnlStudents.Controls.Add(this.listViewStudents);
            this.pnlStudents.Controls.Add(this.pictureBox1);
            this.pnlStudents.Controls.Add(this.lbl_Students);
            this.pnlStudents.Location = new System.Drawing.Point(18, 40);
            this.pnlStudents.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlStudents.Name = "pnlStudents";
            this.pnlStudents.Size = new System.Drawing.Size(1407, 718);
            this.pnlStudents.TabIndex = 4;
            this.pnlStudents.TabStop = true;
            // 
            // listViewStudents
            // 
            this.listViewStudents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.studentID,
            this.studentName,
            this.studentDOB});
            this.listViewStudents.HideSelection = false;
            this.listViewStudents.Location = new System.Drawing.Point(24, 65);
            this.listViewStudents.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listViewStudents.Name = "listViewStudents";
            this.listViewStudents.Size = new System.Drawing.Size(1147, 470);
            this.listViewStudents.TabIndex = 5;
            this.listViewStudents.UseCompatibleStateImageBehavior = false;
            // 
            // studentID
            // 
            this.studentID.Text = "ID";
            // 
            // studentName
            // 
            this.studentName.Text = "Name";
            // 
            // studentDOB
            // 
            this.studentDOB.Text = "Date of Birth";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(1207, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(195, 189);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_Students
            // 
            this.lbl_Students.AutoSize = true;
            this.lbl_Students.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Students.Location = new System.Drawing.Point(15, 15);
            this.lbl_Students.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Students.Name = "lbl_Students";
            this.lbl_Students.Size = new System.Drawing.Size(151, 39);
            this.lbl_Students.TabIndex = 3;
            this.lbl_Students.Text = "Students";
            // 
            // pnlRooms
            // 
            this.pnlRooms.Controls.Add(this.pnlLecturers);
            this.pnlRooms.Controls.Add(this.listViewRooms);
            this.pnlRooms.Controls.Add(this.pictureBox2);
            this.pnlRooms.Controls.Add(this.lbl_Rooms);
            this.pnlRooms.Location = new System.Drawing.Point(14, 40);
            this.pnlRooms.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlRooms.Name = "pnlRooms";
            this.pnlRooms.Size = new System.Drawing.Size(1407, 640);
            this.pnlRooms.TabIndex = 6;
            this.pnlRooms.TabStop = true;
            // 
            // pnlLecturers
            // 
            this.pnlLecturers.Controls.Add(this.listViewLecturers);
            this.pnlLecturers.Controls.Add(this.pictureBox3);
            this.pnlLecturers.Controls.Add(this.lbl_lecturers);
            this.pnlLecturers.Location = new System.Drawing.Point(0, 1);
            this.pnlLecturers.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlLecturers.Name = "pnlLecturers";
            this.pnlLecturers.Size = new System.Drawing.Size(1407, 718);
            this.pnlLecturers.TabIndex = 7;
            this.pnlLecturers.TabStop = true;
            // 
            // listViewLecturers
            // 
            this.listViewLecturers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listViewLecturers.HideSelection = false;
            this.listViewLecturers.Location = new System.Drawing.Point(52, 61);
            this.listViewLecturers.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listViewLecturers.Name = "listViewLecturers";
            this.listViewLecturers.Size = new System.Drawing.Size(1147, 470);
            this.listViewLecturers.TabIndex = 5;
            this.listViewLecturers.UseCompatibleStateImageBehavior = false;
            this.listViewLecturers.SelectedIndexChanged += new System.EventHandler(this.listViewLecturers_SelectedIndexChanged);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "ID";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Name";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Date of Birth";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(1207, 0);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(195, 189);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // lbl_lecturers
            // 
            this.lbl_lecturers.AutoSize = true;
            this.lbl_lecturers.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lecturers.Location = new System.Drawing.Point(17, 7);
            this.lbl_lecturers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_lecturers.Name = "lbl_lecturers";
            this.lbl_lecturers.Size = new System.Drawing.Size(158, 39);
            this.lbl_lecturers.TabIndex = 3;
            this.lbl_lecturers.Text = "Lecturers";
            this.lbl_lecturers.Click += new System.EventHandler(this.lbl_lecturers_Click);
            // 
            // listViewRooms
            // 
            this.listViewRooms.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listViewRooms.HideSelection = false;
            this.listViewRooms.Location = new System.Drawing.Point(24, 65);
            this.listViewRooms.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listViewRooms.Name = "listViewRooms";
            this.listViewRooms.Size = new System.Drawing.Size(1147, 470);
            this.listViewRooms.TabIndex = 5;
            this.listViewRooms.UseCompatibleStateImageBehavior = false;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Name";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Date of Birth";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(1207, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(195, 189);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // lbl_Rooms
            // 
            this.lbl_Rooms.AutoSize = true;
            this.lbl_Rooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Rooms.Location = new System.Drawing.Point(15, 15);
            this.lbl_Rooms.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Rooms.Name = "lbl_Rooms";
            this.lbl_Rooms.Size = new System.Drawing.Size(125, 39);
            this.lbl_Rooms.TabIndex = 3;
            this.lbl_Rooms.Text = "Rooms";
            this.lbl_Rooms.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // pnlDrinks
            // 
            this.pnlDrinks.Controls.Add(this.panel1);
            this.pnlDrinks.Controls.Add(this.AddQueryButt);
            this.pnlDrinks.Controls.Add(this.label5);
            this.pnlDrinks.Controls.Add(this.NewQuerySold);
            this.pnlDrinks.Controls.Add(this.label6);
            this.pnlDrinks.Controls.Add(this.NewQueryPrice);
            this.pnlDrinks.Controls.Add(this.label7);
            this.pnlDrinks.Controls.Add(this.label8);
            this.pnlDrinks.Controls.Add(this.NewQueryStock);
            this.pnlDrinks.Controls.Add(this.NewQueryName);
            this.pnlDrinks.Controls.Add(this.label4);
            this.pnlDrinks.Controls.Add(this.label2);
            this.pnlDrinks.Controls.Add(this.UpdatePriceButton);
            this.pnlDrinks.Controls.Add(this.lbl_NewPrice);
            this.pnlDrinks.Controls.Add(this.UpdateNameButton);
            this.pnlDrinks.Controls.Add(this.lbl_NewName);
            this.pnlDrinks.Controls.Add(this.lbl_NewStock);
            this.pnlDrinks.Controls.Add(this.label3);
            this.pnlDrinks.Controls.Add(this.lbl_DrinkName);
            this.pnlDrinks.Controls.Add(this.UpdateStockButton);
            this.pnlDrinks.Controls.Add(this.listViewDrinkss);
            this.pnlDrinks.Controls.Add(this.pictureBox5);
            this.pnlDrinks.Controls.Add(this.lbl_Drinks);
            this.pnlDrinks.Location = new System.Drawing.Point(14, 38);
            this.pnlDrinks.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlDrinks.Name = "pnlDrinks";
            this.pnlDrinks.Size = new System.Drawing.Size(1407, 718);
            this.pnlDrinks.TabIndex = 8;
            this.pnlDrinks.TabStop = true;
            this.pnlDrinks.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.DeleteQueryButton);
            this.panel1.Controls.Add(this.DeleteQueryNameBox);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.DeleteQuerylbl);
            this.panel1.Controls.Add(this.AddQueryButton);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.NewQueryIDBox);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.NewQuerySoldBox);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.NewQueryPriceBox);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.NewQueryStockBox);
            this.panel1.Controls.Add(this.NewQueryNameBox);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.NewPriceBox);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.NewNameBox);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.NewStockBox);
            this.panel1.Controls.Add(this.DrinkNameBox);
            this.panel1.Controls.Add(this.listViewDrinks);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Location = new System.Drawing.Point(8, 8);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1407, 718);
            this.panel1.TabIndex = 29;
            this.panel1.TabStop = true;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // DeleteQueryButton
            // 
            this.DeleteQueryButton.Location = new System.Drawing.Point(1142, 666);
            this.DeleteQueryButton.Name = "DeleteQueryButton";
            this.DeleteQueryButton.Size = new System.Drawing.Size(146, 38);
            this.DeleteQueryButton.TabIndex = 9;
            this.DeleteQueryButton.Text = "Delete Query";
            this.DeleteQueryButton.UseVisualStyleBackColor = true;
            this.DeleteQueryButton.Click += new System.EventHandler(this.DeleteQueryButton_Click);
            // 
            // DeleteQueryNameBox
            // 
            this.DeleteQueryNameBox.Location = new System.Drawing.Point(1154, 549);
            this.DeleteQueryNameBox.Name = "DeleteQueryNameBox";
            this.DeleteQueryNameBox.Size = new System.Drawing.Size(151, 26);
            this.DeleteQueryNameBox.TabIndex = 34;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1051, 553);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 20);
            this.label1.TabIndex = 33;
            this.label1.Text = "Query Name";
            // 
            // DeleteQuerylbl
            // 
            this.DeleteQuerylbl.AutoSize = true;
            this.DeleteQuerylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteQuerylbl.Location = new System.Drawing.Point(1174, 492);
            this.DeleteQuerylbl.Name = "DeleteQuerylbl";
            this.DeleteQuerylbl.Size = new System.Drawing.Size(114, 20);
            this.DeleteQuerylbl.TabIndex = 32;
            this.DeleteQuerylbl.Text = "Delete Query";
            // 
            // AddQueryButton
            // 
            this.AddQueryButton.Location = new System.Drawing.Point(696, 665);
            this.AddQueryButton.Name = "AddQueryButton";
            this.AddQueryButton.Size = new System.Drawing.Size(146, 38);
            this.AddQueryButton.TabIndex = 31;
            this.AddQueryButton.Text = "Add Query";
            this.AddQueryButton.UseVisualStyleBackColor = true;
            this.AddQueryButton.Click += new System.EventHandler(this.AddQueryButton_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(516, 555);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(72, 20);
            this.label21.TabIndex = 30;
            this.label21.Text = "Query ID";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // NewQueryIDBox
            // 
            this.NewQueryIDBox.Location = new System.Drawing.Point(594, 550);
            this.NewQueryIDBox.Name = "NewQueryIDBox";
            this.NewQueryIDBox.Size = new System.Drawing.Size(140, 26);
            this.NewQueryIDBox.TabIndex = 29;
            this.NewQueryIDBox.TextChanged += new System.EventHandler(this.NewQueryIDBox_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(752, 589);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 20);
            this.label9.TabIndex = 27;
            this.label9.Text = "Query Sold";
            // 
            // NewQuerySoldBox
            // 
            this.NewQuerySoldBox.Location = new System.Drawing.Point(848, 586);
            this.NewQuerySoldBox.Name = "NewQuerySoldBox";
            this.NewQuerySoldBox.Size = new System.Drawing.Size(140, 26);
            this.NewQuerySoldBox.TabIndex = 26;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(502, 631);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 20);
            this.label10.TabIndex = 25;
            this.label10.Text = "Query Price";
            // 
            // NewQueryPriceBox
            // 
            this.NewQueryPriceBox.Location = new System.Drawing.Point(594, 628);
            this.NewQueryPriceBox.Name = "NewQueryPriceBox";
            this.NewQueryPriceBox.Size = new System.Drawing.Size(140, 26);
            this.NewQueryPriceBox.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(746, 551);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 20);
            this.label11.TabIndex = 24;
            this.label11.Text = "Query Stock";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(496, 593);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 20);
            this.label12.TabIndex = 23;
            this.label12.Text = "Query Name";
            // 
            // NewQueryStockBox
            // 
            this.NewQueryStockBox.Location = new System.Drawing.Point(848, 548);
            this.NewQueryStockBox.Name = "NewQueryStockBox";
            this.NewQueryStockBox.Size = new System.Drawing.Size(140, 26);
            this.NewQueryStockBox.TabIndex = 21;
            // 
            // NewQueryNameBox
            // 
            this.NewQueryNameBox.Location = new System.Drawing.Point(594, 590);
            this.NewQueryNameBox.Name = "NewQueryNameBox";
            this.NewQueryNameBox.Size = new System.Drawing.Size(140, 26);
            this.NewQueryNameBox.TabIndex = 20;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(673, 492);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 20);
            this.label13.TabIndex = 19;
            this.label13.Text = "Add Query";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(240, 492);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(120, 20);
            this.label14.TabIndex = 18;
            this.label14.Text = "Update Query";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(305, 666);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(146, 38);
            this.button2.TabIndex = 17;
            this.button2.Text = "Update Price";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(54, 676);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 20);
            this.label15.TabIndex = 16;
            this.label15.Text = "New Price";
            // 
            // NewPriceBox
            // 
            this.NewPriceBox.Location = new System.Drawing.Point(146, 673);
            this.NewPriceBox.Name = "NewPriceBox";
            this.NewPriceBox.Size = new System.Drawing.Size(140, 26);
            this.NewPriceBox.TabIndex = 15;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(305, 622);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(146, 38);
            this.button3.TabIndex = 14;
            this.button3.Text = "Update Name";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(54, 631);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 20);
            this.label16.TabIndex = 13;
            this.label16.Text = "New Name";
            // 
            // NewNameBox
            // 
            this.NewNameBox.Location = new System.Drawing.Point(146, 628);
            this.NewNameBox.Name = "NewNameBox";
            this.NewNameBox.Size = new System.Drawing.Size(140, 26);
            this.NewNameBox.TabIndex = 9;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(55, 586);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(85, 20);
            this.label17.TabIndex = 12;
            this.label17.Text = "New Stock";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(686, 357);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 20);
            this.label18.TabIndex = 11;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(48, 545);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(92, 20);
            this.label19.TabIndex = 9;
            this.label19.Text = "Drink Name";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(305, 577);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(146, 38);
            this.button4.TabIndex = 8;
            this.button4.Text = "Update Stock";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // NewStockBox
            // 
            this.NewStockBox.Location = new System.Drawing.Point(146, 583);
            this.NewStockBox.Name = "NewStockBox";
            this.NewStockBox.Size = new System.Drawing.Size(140, 26);
            this.NewStockBox.TabIndex = 7;
            // 
            // DrinkNameBox
            // 
            this.DrinkNameBox.Location = new System.Drawing.Point(146, 542);
            this.DrinkNameBox.Name = "DrinkNameBox";
            this.DrinkNameBox.Size = new System.Drawing.Size(140, 26);
            this.DrinkNameBox.TabIndex = 6;
            this.DrinkNameBox.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // listViewDrinks
            // 
            this.listViewDrinks.BackColor = System.Drawing.SystemColors.Info;
            this.listViewDrinks.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12});
            this.listViewDrinks.GridLines = true;
            this.listViewDrinks.HideSelection = false;
            this.listViewDrinks.Location = new System.Drawing.Point(24, 56);
            this.listViewDrinks.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listViewDrinks.Name = "listViewDrinks";
            this.listViewDrinks.Size = new System.Drawing.Size(1147, 417);
            this.listViewDrinks.TabIndex = 5;
            this.listViewDrinks.UseCompatibleStateImageBehavior = false;
            this.listViewDrinks.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged_2);
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "ID";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Name";
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Date of Birth";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox4.InitialImage = null;
            this.pictureBox4.Location = new System.Drawing.Point(1207, 0);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(195, 189);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(17, 7);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(114, 39);
            this.label20.TabIndex = 3;
            this.label20.Text = "Drinks";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // AddQueryButt
            // 
            this.AddQueryButt.Location = new System.Drawing.Point(753, 694);
            this.AddQueryButt.Name = "AddQueryButt";
            this.AddQueryButt.Size = new System.Drawing.Size(266, 10);
            this.AddQueryButt.TabIndex = 28;
            this.AddQueryButt.Text = "Add Query";
            this.AddQueryButt.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(752, 589);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 20);
            this.label5.TabIndex = 27;
            this.label5.Text = "Query Sold";
            // 
            // NewQuerySold
            // 
            this.NewQuerySold.Location = new System.Drawing.Point(837, 586);
            this.NewQuerySold.Name = "NewQuerySold";
            this.NewQuerySold.Size = new System.Drawing.Size(140, 26);
            this.NewQuerySold.TabIndex = 26;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(495, 589);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 20);
            this.label6.TabIndex = 25;
            this.label6.Text = "Query Price";
            // 
            // NewQueryPrice
            // 
            this.NewQueryPrice.Location = new System.Drawing.Point(587, 586);
            this.NewQueryPrice.Name = "NewQueryPrice";
            this.NewQueryPrice.Size = new System.Drawing.Size(140, 26);
            this.NewQueryPrice.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(746, 551);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 20);
            this.label7.TabIndex = 24;
            this.label7.Text = "Query Stock";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(489, 551);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 20);
            this.label8.TabIndex = 23;
            this.label8.Text = "Query Name";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // NewQueryStock
            // 
            this.NewQueryStock.Location = new System.Drawing.Point(837, 548);
            this.NewQueryStock.Name = "NewQueryStock";
            this.NewQueryStock.Size = new System.Drawing.Size(140, 26);
            this.NewQueryStock.TabIndex = 21;
            this.NewQueryStock.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // NewQueryName
            // 
            this.NewQueryName.Location = new System.Drawing.Point(587, 548);
            this.NewQueryName.Name = "NewQueryName";
            this.NewQueryName.Size = new System.Drawing.Size(140, 26);
            this.NewQueryName.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(673, 492);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 20);
            this.label4.TabIndex = 19;
            this.label4.Text = "Update Query";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(240, 492);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Update Query";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // UpdatePriceButton
            // 
            this.UpdatePriceButton.Location = new System.Drawing.Point(305, 666);
            this.UpdatePriceButton.Name = "UpdatePriceButton";
            this.UpdatePriceButton.Size = new System.Drawing.Size(146, 38);
            this.UpdatePriceButton.TabIndex = 17;
            this.UpdatePriceButton.Text = "Update Price";
            this.UpdatePriceButton.UseVisualStyleBackColor = true;
            this.UpdatePriceButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbl_NewPrice
            // 
            this.lbl_NewPrice.AutoSize = true;
            this.lbl_NewPrice.Location = new System.Drawing.Point(54, 676);
            this.lbl_NewPrice.Name = "lbl_NewPrice";
            this.lbl_NewPrice.Size = new System.Drawing.Size(79, 20);
            this.lbl_NewPrice.TabIndex = 16;
            this.lbl_NewPrice.Text = "New Price";
            this.lbl_NewPrice.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // UpdateNameButton
            // 
            this.UpdateNameButton.Location = new System.Drawing.Point(305, 622);
            this.UpdateNameButton.Name = "UpdateNameButton";
            this.UpdateNameButton.Size = new System.Drawing.Size(146, 38);
            this.UpdateNameButton.TabIndex = 14;
            this.UpdateNameButton.Text = "Update Name";
            this.UpdateNameButton.UseVisualStyleBackColor = true;
            this.UpdateNameButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_NewName
            // 
            this.lbl_NewName.AutoSize = true;
            this.lbl_NewName.Location = new System.Drawing.Point(54, 631);
            this.lbl_NewName.Name = "lbl_NewName";
            this.lbl_NewName.Size = new System.Drawing.Size(86, 20);
            this.lbl_NewName.TabIndex = 13;
            this.lbl_NewName.Text = "New Name";
            this.lbl_NewName.Click += new System.EventHandler(this.label2_Click);
            // 
            // lbl_NewStock
            // 
            this.lbl_NewStock.AutoSize = true;
            this.lbl_NewStock.Location = new System.Drawing.Point(55, 586);
            this.lbl_NewStock.Name = "lbl_NewStock";
            this.lbl_NewStock.Size = new System.Drawing.Size(85, 20);
            this.lbl_NewStock.TabIndex = 12;
            this.lbl_NewStock.Text = "New Stock";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(686, 357);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 20);
            this.label3.TabIndex = 11;
            // 
            // lbl_DrinkName
            // 
            this.lbl_DrinkName.AutoSize = true;
            this.lbl_DrinkName.Location = new System.Drawing.Point(48, 545);
            this.lbl_DrinkName.Name = "lbl_DrinkName";
            this.lbl_DrinkName.Size = new System.Drawing.Size(92, 20);
            this.lbl_DrinkName.TabIndex = 9;
            this.lbl_DrinkName.Text = "Drink Name";
            // 
            // UpdateStockButton
            // 
            this.UpdateStockButton.Location = new System.Drawing.Point(305, 577);
            this.UpdateStockButton.Name = "UpdateStockButton";
            this.UpdateStockButton.Size = new System.Drawing.Size(146, 38);
            this.UpdateStockButton.TabIndex = 8;
            this.UpdateStockButton.Text = "Update Stock";
            this.UpdateStockButton.UseVisualStyleBackColor = true;
            this.UpdateStockButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // listViewDrinkss
            // 
            this.listViewDrinkss.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9});
            this.listViewDrinkss.HideSelection = false;
            this.listViewDrinkss.Location = new System.Drawing.Point(52, 61);
            this.listViewDrinkss.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listViewDrinkss.Name = "listViewDrinkss";
            this.listViewDrinkss.Size = new System.Drawing.Size(1147, 417);
            this.listViewDrinkss.TabIndex = 5;
            this.listViewDrinkss.UseCompatibleStateImageBehavior = false;
            this.listViewDrinkss.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged_1);
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "ID";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Name";
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Date of Birth";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox5.InitialImage = null;
            this.pictureBox5.Location = new System.Drawing.Point(1207, 0);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(195, 189);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // lbl_Drinks
            // 
            this.lbl_Drinks.AutoSize = true;
            this.lbl_Drinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Drinks.Location = new System.Drawing.Point(17, 7);
            this.lbl_Drinks.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Drinks.Name = "lbl_Drinks";
            this.lbl_Drinks.Size = new System.Drawing.Size(114, 39);
            this.lbl_Drinks.TabIndex = 3;
            this.lbl_Drinks.Text = "Drinks";
            this.lbl_Drinks.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // SomerenUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1443, 778);
            this.Controls.Add(this.pnlDrinks);
            this.Controls.Add(this.pnlRooms);
            this.Controls.Add(this.pnlStudents);
            this.Controls.Add(this.pnlDashboard);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SomerenUI";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "SomerenApp";
            this.Load += new System.EventHandler(this.SomerenUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgDashboard)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlDashboard.ResumeLayout(false);
            this.pnlDashboard.PerformLayout();
            this.pnlStudents.ResumeLayout(false);
            this.pnlStudents.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlRooms.ResumeLayout(false);
            this.pnlRooms.PerformLayout();
            this.pnlLecturers.ResumeLayout(false);
            this.pnlLecturers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlDrinks.ResumeLayout(false);
            this.pnlDrinks.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox imgDashboard;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dashboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dashboardToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel pnlDashboard;
        private System.Windows.Forms.Label lbl_Dashboard;

        private System.Windows.Forms.ToolStripMenuItem studentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lecturersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activitiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roomsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem drinksToolStripMenuItem;

        private System.Windows.Forms.Panel pnlStudents;
        private System.Windows.Forms.Label lbl_Students;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listViewStudents;
        private System.Windows.Forms.ColumnHeader studentID;
        private System.Windows.Forms.ColumnHeader studentName;
        private System.Windows.Forms.ColumnHeader studentDOB;

        private System.Windows.Forms.Panel pnlRooms;
        private System.Windows.Forms.Label lbl_Rooms;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ListView listViewRooms;        
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        
        
        private System.Windows.Forms.Panel pnlLecturers;
        private System.Windows.Forms.Label lbl_lecturers;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ListView listViewLecturers;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;

        private System.Windows.Forms.Panel pnlDrinks;
        private System.Windows.Forms.Label lbl_Drinks;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.ListView listViewDrinkss;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.Label lbl_NewStock;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_DrinkName;
        private System.Windows.Forms.Button UpdateStockButton;
        private System.Windows.Forms.Label lbl_NewName;
        private System.Windows.Forms.Button UpdateNameButton;
        private System.Windows.Forms.Button UpdatePriceButton;
        private System.Windows.Forms.Label lbl_NewPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox NewQuerySold;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox NewQueryPrice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox NewQueryStock;
        private System.Windows.Forms.TextBox NewQueryName;
        private System.Windows.Forms.Button AddQueryButt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox NewQueryIDBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox NewQuerySoldBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox NewQueryPriceBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox NewQueryStockBox;
        private System.Windows.Forms.TextBox NewQueryNameBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox NewPriceBox;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox NewNameBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox NewStockBox;
        private System.Windows.Forms.TextBox DrinkNameBox;
        private System.Windows.Forms.ListView listViewDrinks;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button AddQueryButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label DeleteQuerylbl;
        private System.Windows.Forms.Button DeleteQueryButton;
        private System.Windows.Forms.TextBox DeleteQueryNameBox;

        //private System.Windows.Forms.ColumnHeader drinkID;
        //private System.Windows.Forms.ColumnHeader drinkName;
        //private System.Windows.Forms.ColumnHeader drinkPrice;
        //private System.Windows.Forms.ColumnHeader drinkStock;
        //private System.Windows.Forms.ColumnHeader drinkSold;

    }
}

